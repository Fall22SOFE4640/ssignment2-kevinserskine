package com.example.assignment2_kevinerskine;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
